var x = document.querySelector("#S");
var y = document.querySelector("#N");
var s = document.querySelector("#Q");
var t= document.querySelector("#U");
var u = document.querySelector("#D");
var v = document.querySelector("#not");
var z = document.querySelector("#tab");
var a = document.querySelector("#Department");

function loadJSON() {
    x.innerHTML="Serial No";
    y.innerHTML="Item";    
    s.innerHTML="Quantity";
    t.innerHTML="Unit";
    u.innerHTML="Department";
    v.innerHTML="Notes";

    var http_request = new XMLHttpRequest();
    try{
       // Opera 8.0+, Firefox, Chrome, Safari
       http_request = new XMLHttpRequest();
    }catch (e) {
       // Internet Explorer Browsers
       try{
          http_request = new ActiveXObject("Msxml2.XMLHTTP");
            
       }catch (e) {
        
          try{
             http_request = new ActiveXObject("Microsoft.XMLHTTP");
          }catch (e) {
             // Something went wrong
             alert("Your browser broke!");
             return false;
          }
            
       }
    }
    
    http_request.onreadystatechange = function() {
    
       if (http_request.readyState == 4  ) {
          // Javascript function JSON.parse to parse JSON data
          var jsonObj = JSON.parse(http_request.responseText);
          var Jgroc = jsonObj.grocery;
          console.log(Jgroc);
          document.getElementById("serialno").innerHTML ="";
          document.getElementById("Name").innerHTML ="";
          document.getElementById("quantity").innerHTML ="";
          document.getElementById("unit").innerHTML="";
          document.getElementById("Department").innerHTML ="";
          document.getElementById("Notes").innerHTML="";

          for(i=0;i<Jgroc.length;i++)
          {
            
          
          // jsonObj variable now contains the data structure 
          document.getElementById("serialno").innerHTML +=Jgroc[i].serialno + "<br/>";
          document.getElementById("Name").innerHTML += Jgroc[i].item + "<br/>";
          document.getElementById("quantity").innerHTML += Jgroc[i].quantity + "<br/>";
          document.getElementById("unit").innerHTML += Jgroc[i].unit + "<br/>";
          document.getElementById("Department").innerHTML += Jgroc[i].department + "<br/>";
          document.getElementById("Notes").innerHTML+= Jgroc[i].notes + "<br/>";
          

          }

          z.style.border ="1px solid red";
          x.style.backgroundColor ="rgb(137, 188, 192)";
          y.style.backgroundColor ="rgb(137, 188, 192)";
          s.style.backgroundColor ="rgb(137, 188, 192)";
          t.style.backgroundColor ="rgb(137, 188, 192)";
          u.style.backgroundColor ="rgb(137, 188, 192)";
          v.style.backgroundColor ="rgb(137, 188, 192)";




         // z.style.backgroundColor="yellow";
          z.style.backgroundImage= "url('https://visme.co/blog/wp-content/uploads/2017/07/50-Beautiful-and-Minimalist-Presentation-Backgrounds-05.jpg')";
         // console.log(a);
   //     if(a=="Fruits & Veg"||"Sea food"||"Home Decor"||"Health & Beauty"||"Food_item"||"Cleaning & Laundry"||"Dry_nuts & Fruits"||"Reynolds Gel Black"||"Dairy Products");
   //  {
   //       if(a=="Fruits & Veg")
   //          {
   //             alert("hi");
   //             a.style.color="red";
   //          }
   //  } 

       }
    }         // z.style.borderCollapse ="collapse";

    
    http_request.open("GET", "list.json", true);
    http_request.send();

   }
